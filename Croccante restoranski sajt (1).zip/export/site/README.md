# Croccante — sajt (spreman za GitHub Pages)

Sadržaj ovog foldera je ceo sajt. Sve slike, fontovi i kod su unutar `index.html`,
pa nema dodatnih fajlova koje treba prenositi.

## Postavljanje na GitHub Pages

1. Napravite novi repozitorijum na github.com (npr. `croccante`).
2. Prevucite `index.html` i `.nojekyll` u repozitorijum (Add file → Upload files) i sačuvajte.
3. Settings → Pages → Source: **Deploy from a branch**, Branch: **main**, folder: **/ (root)** → Save.
4. Nakon minut-dva sajt je živ na `https://<vase-ime>.github.io/croccante/`.

## Sopstveni domen (npr. croccante.rs)

Settings → Pages → Custom domain: upišite domen, pa kod registratora domena
dodajte CNAME zapis koji pokazuje na `<vase-ime>.github.io`.

## Napomene

- Stranice su povezane preko adresa tipa `#/meni`, `#/poruci`, `#/galerija`, `#/kontakt`
  — rade i direktnim otvaranjem linka i na GitHub Pages.
- Sajt je responsive: desktop od 1000px pa naviše (sa jelovnikom-knjigom),
  telefon ispod toga (lista jelovnika).
- Porudžbine i rezervacije se šalju na WhatsApp broj +381 63 879 0766.
  Broj se menja u izvornom fajlu (`CROCCANTE v5.dc.html`) i sajt se ponovo izveze.
- Video u galeriji se učitava sa YouTube-a, pa za njega treba internet.
